import { setWmProjectProperties } from '@wm/core';

const properties = {
    "copyrightMsg": "Copyright (c) 2016-2017 wavemaker.com All Rights Reserved.\n This software is the confidential and proprietary information of wavemaker.com You shall not disclose such Confidential Information and shall use it only in accordance\n with the terms of the source code license agreement you entered into with wavemaker.com",
    "homePage": "Main",
    "studioProjectUpgradeVersion": "102.02",
    "packagePrefix": "com.variables_mobile",
    "platformType": "MOBILE",
    "deviceTypes": "",
    "version": "1.0",
    "type": "APPLICATION",
    "defaultLanguage": "en",
    "icon": "default.png",
    "projectShellName": "WM_DEFAULT",
    "displayName": "Mobile_Securtity",
    "activeTheme": "mobile",
    "description": "Variables_Mobile"
}

setWmProjectProperties(properties);

export default () => {};
