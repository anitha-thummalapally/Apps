export const variables = {
  "appInfo" : {
    "_id" : "wm-getAppInfo-wm.DeviceVariable-1444134876543",
    "name" : "appInfo",
    "owner" : "App",
    "category" : "wm.DeviceVariable",
    "dataBinding" : [ ],
    "service" : "device",
    "operation" : "getAppInfo",
    "dataSet" : {
      "appversion" : "X.X.X",
      "cordovaversion" : "X.X.X"
    },
    "startUpdate" : true
  },
  "appNotification" : {
    "_id" : "wm-appErrorHandler-wm.NotificationVariable-1454664620943",
    "name" : "appNotification",
    "owner" : "App",
    "category" : "wm.NotificationVariable",
    "dataBinding" : [ {
      "target" : "class",
      "value" : "Error",
      "type" : "list"
    }, {
      "target" : "toasterPosition",
      "value" : "bottom right",
      "type" : "list"
    } ],
    "operation" : "toast"
  },
  "deviceInfo" : {
    "_id" : "wm-deviceInfo-getDeviceInfo-wm.DeviceVariable-1444134852623",
    "name" : "deviceInfo",
    "owner" : "App",
    "category" : "wm.DeviceVariable",
    "dataBinding" : [ ],
    "service" : "device",
    "operation" : "getDeviceInfo",
    "dataSet" : {
      "connectionType" : "NONE",
      "deviceModel" : "DEVICEMODEL",
      "os" : "DEVICEOS",
      "osVersion" : "X.X.X",
      "deviceUUID" : "DEVICEUUID"
    },
    "startUpdate" : true
  },
  "goToPage_Actions" : {
    "_id" : "wm-goToPage_Actions-wm.NavigationVariable-1549869942359",
    "name" : "goToPage_Actions",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "Actions",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_AdminPage" : {
    "_id" : "wm-goToPage_AdminPage-wm.NavigationVariable-1561621500018",
    "name" : "goToPage_AdminPage",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "AdminPage",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_DatabaseAPI" : {
    "_id" : "wm-goToPage_DatabaseAPI-wm.NavigationVariable-1549869915720",
    "name" : "goToPage_DatabaseAPI",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "DatabaseAPI",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_DeviceVariables" : {
    "_id" : "wm-goToPage_DeviceVariables-wm.NavigationVariable-1549869982772",
    "name" : "goToPage_DeviceVariables",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "DeviceVariables",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_JavaServices" : {
    "_id" : "wm-goToPage_JavaServices-wm.NavigationVariable-1549869934176",
    "name" : "goToPage_JavaServices",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "JavaServices",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_Main" : {
    "_id" : "wm-wm.NavigationVariable1389180517517",
    "name" : "goToPage_Main",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "operation" : "gotoPage",
    "pageName" : "Main"
  },
  "goToPage_RecurringVariables" : {
    "_id" : "wm-goToPage_RecurringVariables-wm.NavigationVariable-1549869973516",
    "name" : "goToPage_RecurringVariables",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "RecurringVariables",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_SecurityInfo" : {
    "_id" : "wm-goToPage_SecurityInfo-wm.NavigationVariable-1561621597959",
    "name" : "goToPage_SecurityInfo",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "SecurityInfo",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_StaticVariable" : {
    "_id" : "wm-goToPage_StaticVariable-wm.NavigationVariable-1549869958376",
    "name" : "goToPage_StaticVariable",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "StaticVariable",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_UserPage" : {
    "_id" : "wm-goToPage_UserPage1-wm.NavigationVariable-1561626032118",
    "name" : "goToPage_UserPage",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "UserPage",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_WebServices" : {
    "_id" : "wm-goToPage_WebServices-wm.NavigationVariable-1549869927542",
    "name" : "goToPage_WebServices",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "WebServices",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "loggedInUser" : {
    "_id" : "wm-loggedInUser-wm.Variable-1549880988494",
    "name" : "loggedInUser",
    "owner" : "App",
    "category" : "wm.Variable",
    "dataBinding" : [ ],
    "dataSet" : {
      "name" : "",
      "id" : "",
      "tenantId" : "",
      "isAuthenticated" : false,
      "isSecurityEnabled" : true,
      "roles" : [ ]
    },
    "type" : "string",
    "isList" : false,
    "saveInPhonegap" : false,
    "twoWayBinding" : false
  },
  "loginAction" : {
    "_id" : "wm-loginAction-wm.LoginVariable-1549880988492",
    "name" : "loginAction",
    "owner" : "App",
    "category" : "wm.LoginVariable",
    "dataBinding" : [ {
      "target" : "j_username",
      "value" : "bind:Widgets.j_username.datavalue",
      "type" : "string"
    }, {
      "target" : "j_password",
      "value" : "bind:Widgets.j_password.datavalue",
      "type" : "string"
    }, {
      "target" : "j_rememberme",
      "value" : "bind:Widgets.j_rememberme.datavalue",
      "type" : "boolean"
    } ],
    "dataSet" : {
      "j_password" : "",
      "j_rememberme" : false,
      "j_username" : ""
    },
    "type" : "string",
    "saveInPhonegap" : false,
    "startUpdate" : false,
    "autoUpdate" : false,
    "inFlightBehavior" : "executeLast",
    "transformationRequired" : false,
    "useDefaultSuccessHandler" : true
  },
  "logoutAction" : {
    "_id" : "wm-logoutAction-wm.LogoutVariable-1549880988493",
    "name" : "logoutAction",
    "owner" : "App",
    "category" : "wm.LogoutVariable",
    "type" : "string",
    "saveInPhonegap" : false,
    "inFlightBehavior" : "executeLast",
    "transformationRequired" : false,
    "redirectTo" : "Login",
    "useDefaultSuccessHandler" : true
  },
  "SecurityInfoPageStaticVariable" : {
    "_id" : "wm-staticVariable1-wm.Variable-1561627242999",
    "name" : "SecurityInfoPageStaticVariable",
    "owner" : "App",
    "category" : "wm.Variable",
    "dataBinding" : [ ],
    "dataSet" : [ {
      "label" : "SecurityInfo",
      "icon" : "wi wi-security",
      "link" : "#SecurityInfo",
      "id" : "SecurityInfo"
    } ],
    "type" : "entry",
    "isList" : true,
    "saveInPhonegap" : false,
    "twoWayBinding" : false
  },
  "supportedLocale" : {
    "_id" : "wm-wm.Variable1402640443182",
    "name" : "supportedLocale",
    "owner" : "App",
    "category" : "wm.Variable",
    "dataSet" : {
      "en" : "English"
    },
    "type" : "string",
    "isList" : false,
    "saveInPhonegap" : false,
    "twoWayBinding" : false
  }
};

export const getVariables = () => JSON.parse(JSON.stringify(variables));
