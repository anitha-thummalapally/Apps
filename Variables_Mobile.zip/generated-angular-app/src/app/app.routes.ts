import { Routes } from "@angular/router"

import {
    AppJSResolve,
    AppVariablesResolve,
    AuthGuard,
    MetadataResolve,
    RoleGuard,
    SecurityConfigResolve,
    EmptyPageComponent,
    PageNotFoundGaurd
} from "@wm/runtime/base"

const appDependenciesResolve = {
    metadata: MetadataResolve,
    appJS: AppJSResolve,
    appVariables: AppVariablesResolve,
    securityConfig: SecurityConfigResolve
}

export const routes: Routes = [
    {
        path: "",
        pathMatch: "full",
        component: EmptyPageComponent,
        resolve: appDependenciesResolve
    },
    {
        path: "",
        resolve: appDependenciesResolve,
        children: [
            {
                path: "Actions",
                pathMatch: "full",
                loadChildren: "./pages/Actions/Actions.module#ActionsModule",
                canActivate: [AuthGuard]
            },
            {
                path: "AdminPage",
                pathMatch: "full",
                loadChildren:
                    "./pages/AdminPage/AdminPage.module#AdminPageModule",
                canActivate: [AuthGuard]
            },
            {
                path: "DatabaseAPI",
                pathMatch: "full",
                loadChildren:
                    "./pages/DatabaseAPI/DatabaseAPI.module#DatabaseAPIModule",
                canActivate: [AuthGuard]
            },
            {
                path: "DeviceVariables",
                pathMatch: "full",
                loadChildren:
                    "./pages/DeviceVariables/DeviceVariables.module#DeviceVariablesModule",
                canActivate: [AuthGuard]
            },
            {
                path: "JavaServices",
                pathMatch: "full",
                loadChildren:
                    "./pages/JavaServices/JavaServices.module#JavaServicesModule",
                canActivate: [AuthGuard]
            },
            {
                path: "Login",
                pathMatch: "full",
                loadChildren: "./pages/Login/Login.module#LoginModule"
            },
            {
                path: "Main",
                pathMatch: "full",
                loadChildren: "./pages/Main/Main.module#MainModule",
                canActivate: [AuthGuard]
            },
            {
                path: "RecurringVariables",
                pathMatch: "full",
                loadChildren:
                    "./pages/RecurringVariables/RecurringVariables.module#RecurringVariablesModule",
                canActivate: [AuthGuard]
            },
            {
                path: "SecurityInfo",
                pathMatch: "full",
                loadChildren:
                    "./pages/SecurityInfo/SecurityInfo.module#SecurityInfoModule",
                canActivate: [AuthGuard]
            },
            {
                path: "StaticVariable",
                pathMatch: "full",
                loadChildren:
                    "./pages/StaticVariable/StaticVariable.module#StaticVariableModule",
                canActivate: [AuthGuard]
            },
            {
                path: "UserPage",
                pathMatch: "full",
                loadChildren: "./pages/UserPage/UserPage.module#UserPageModule",
                canActivate: [AuthGuard]
            },
            {
                path: "WebServices",
                pathMatch: "full",
                loadChildren:
                    "./pages/WebServices/WebServices.module#WebServicesModule",
                canActivate: [AuthGuard]
            }
        ]
    },
    {
        path: "**",
        canActivate: [PageNotFoundGaurd],
        component: EmptyPageComponent
    }
]
