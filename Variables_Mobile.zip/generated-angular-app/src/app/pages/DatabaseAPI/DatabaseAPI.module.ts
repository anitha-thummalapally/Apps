import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeGenModule } from '../../app-codegen.module';



import { DatabaseAPIComponent } from './DatabaseAPI.component';

const components = [DatabaseAPIComponent];

const routes: Routes = [
    {
        path: '',
        component: DatabaseAPIComponent
    }
];

const requiredComponentModules = [
    
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule
    ],
    exports: components
})
export class DatabaseAPIModule {

}

