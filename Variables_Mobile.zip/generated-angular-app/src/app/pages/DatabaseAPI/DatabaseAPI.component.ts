import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './DatabaseAPI.component.script';
import { getVariables } from './DatabaseAPI.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-DatabaseAPI',
    templateUrl: './DatabaseAPI.component.html',
    styleUrls: ['./DatabaseAPI.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: DatabaseAPIComponent
        }
    ]
})
export class DatabaseAPIComponent extends BasePageComponent {

    pageName = 'DatabaseAPI';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
