export const variables = {
    ClassicmodelsExecuteProcedure_BuildEmailList: {
        _id:
            "wm-ClassicmodelsExecuteProcedure_BuildEmailList-wm.ServiceVariable-1549879187316",
        name: "ClassicmodelsExecuteProcedure_BuildEmailList",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type:
            "com.variables_mobile.classicmodels.models.procedure.ProcedureBuildEmailListResponse",
        service: "classicmodels",
        operation: "executeProcedure_BuildEmailList",
        operationId:
            "ProcedureExecutionController_executeProcedure_BuildEmailList",
        operationType: "get",
        serviceType: "DataService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "ProcedureExecution"
    },
    ClassicmodelsExecuteQuery_Products: {
        _id:
            "wm-ClassicmodelsExecuteQuery_Products-wm.ServiceVariable-1549879132535",
        name: "ClassicmodelsExecuteQuery_Products",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type:
            "com.variables_mobile.classicmodels.models.query.QueryProductsResponse",
        service: "classicmodels",
        operation: "executeQuery_Products",
        operationId: "QueryExecutionController_executeQuery_Products",
        operationType: "get",
        serviceType: "DataService",
        dataSet: [],
        isList: true,
        maxResults: 20,
        startUpdate: true,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "QueryExecution"
    },
    HrdbFindEmployees: {
        _id: "wm-HrdbFindEmployees-wm.ServiceVariable-1549878755367",
        name: "HrdbFindEmployees",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "q",
                value: "empId = 1",
                type: "string"
            }
        ],
        type: "com.variables_mobile.hrdb.Employee",
        service: "hrdb",
        operation: "findEmployees",
        operationId: "EmployeeController_findEmployees",
        operationType: "get",
        serviceType: "DataService",
        dataSet: [],
        isList: true,
        maxResults: 20,
        startUpdate: true,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "Employee"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
