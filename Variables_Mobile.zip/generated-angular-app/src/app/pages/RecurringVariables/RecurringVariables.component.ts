import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './RecurringVariables.component.script';
import { getVariables } from './RecurringVariables.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-RecurringVariables',
    templateUrl: './RecurringVariables.component.html',
    styleUrls: ['./RecurringVariables.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: RecurringVariablesComponent
        }
    ]
})
export class RecurringVariablesComponent extends BasePageComponent {

    pageName = 'RecurringVariables';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
