import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeGenModule } from '../../app-codegen.module';



import { RecurringVariablesComponent } from './RecurringVariables.component';

const components = [RecurringVariablesComponent];

const routes: Routes = [
    {
        path: '',
        component: RecurringVariablesComponent
    }
];

const requiredComponentModules = [
    
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule
    ],
    exports: components
})
export class RecurringVariablesModule {

}

