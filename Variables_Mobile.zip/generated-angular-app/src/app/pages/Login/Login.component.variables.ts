export const variables = {}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
