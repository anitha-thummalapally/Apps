import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './WebServices.component.script';
import { getVariables } from './WebServices.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-WebServices',
    templateUrl: './WebServices.component.html',
    styleUrls: ['./WebServices.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: WebServicesComponent
        }
    ]
})
export class WebServicesComponent extends BasePageComponent {

    pageName = 'WebServices';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
