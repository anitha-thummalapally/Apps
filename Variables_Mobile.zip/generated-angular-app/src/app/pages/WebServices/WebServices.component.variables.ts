export const variables = {
    Calculator_Multiply: {
        _id: "wm-Calculator_Multiply-wm.ServiceVariable-1549879523233",
        name: "Calculator_Multiply",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "intA",
                value: "13",
                type: "integer"
            },
            {
                target: "intB",
                value: "2",
                type: "integer"
            }
        ],
        type: "com.variables_mobile.services.calculator.MultiplyResponse",
        service: "Calculator",
        operation: "multiply",
        operationId: "CalculatorController_multiply",
        operationType: "get",
        serviceType: "SoapService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: true,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "Calculator"
    },
    Fda: {
        _id: "wm-Fda-wm.ServiceVariable-1549879486857",
        name: "Fda",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "search",
                value:
                    'patient.drug.openfda.pharm_class_epc:"nonsteroidal+anti-inflammatory+drug"',
                type: "string"
            },
            {
                target: "count",
                value: "patient.reaction.reactionmeddrapt.exact",
                type: "string"
            }
        ],
        type: "fda.RootResponse",
        service: "fda",
        operation: "invoke",
        operationId: "fda_RestServiceVirtualController-invoke",
        operationType: "get",
        serviceType: "RestService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: true,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "RestServiceVirtual"
    },
    HeartRate_WebSocket: {
        _id: "wm-HeartRate_WebSocket-wm.WebSocketVariable-1549879554234",
        name: "HeartRate_WebSocket",
        owner: "Page",
        category: "wm.WebSocketVariable",
        dataBinding: [],
        service: "HeartRate",
        operationId: "HeartRate_WebSocketServiceVirtualController-invoke",
        dataSet: [],
        type: "HeartRate.RootResponse",
        isDefault: false,
        isList: false,
        startUpdate: true,
        dataUpdateStrategy: "refresh",
        dataLimit: 20
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
