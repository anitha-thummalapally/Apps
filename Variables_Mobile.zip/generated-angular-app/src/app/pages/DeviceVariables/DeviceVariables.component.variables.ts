export const variables = {
    Calendar_GetEvents: {
        _id: "wm-Calendar_GetEvents-wm.DeviceVariable-1549881710165",
        name: "Calendar_GetEvents",
        owner: "Page",
        category: "wm.DeviceVariable",
        dataBinding: [],
        service: "calendar",
        operation: "getEvents",
        dataSet: [
            {
                title: "",
                message: "",
                location: "",
                startDate: "",
                endDate: ""
            }
        ]
    },
    Calender_CreateEvent: {
        _id: "wm-Calender_CreateEvent-wm.DeviceVariable-1549881681289",
        name: "Calender_CreateEvent",
        owner: "Page",
        category: "wm.DeviceVariable",
        dataBinding: [],
        service: "calendar",
        operation: "createEvent"
    },
    CaptureImage: {
        _id: "wm-CaptureImage-wm.DeviceVariable-1549881806638",
        name: "CaptureImage",
        owner: "Page",
        category: "wm.DeviceVariable",
        dataBinding: [
            {
                target: "allowImageEdit",
                value: false,
                type: "boolean"
            },
            {
                target: "imageQuality",
                value: 80,
                type: "number"
            },
            {
                target: "imageEncodingType",
                value: "0",
                type: "list"
            },
            {
                target: "correctOrientation",
                value: true,
                type: "boolean"
            }
        ],
        service: "camera",
        operation: "captureImage",
        dataSet: {
            imagePath: "resources/images/imagelists/default-image.png"
        }
    },
    CaptureVideo: {
        _id: "wm-CaptureVideo-wm.DeviceVariable-1549881825358",
        name: "CaptureVideo",
        owner: "Page",
        category: "wm.DeviceVariable",
        dataBinding: [],
        service: "camera",
        operation: "captureVideo",
        dataSet: {
            videoPath: ""
        }
    },
    DeleteEvents: {
        _id: "wm-DeleteEvents-wm.DeviceVariable-1549881733142",
        name: "DeleteEvents",
        owner: "Page",
        category: "wm.DeviceVariable",
        dataBinding: [],
        service: "calendar",
        operation: "deleteEvent"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
