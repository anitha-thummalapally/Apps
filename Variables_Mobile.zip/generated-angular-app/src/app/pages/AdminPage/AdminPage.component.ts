import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './AdminPage.component.script';
import { getVariables } from './AdminPage.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-AdminPage',
    templateUrl: './AdminPage.component.html',
    styleUrls: ['./AdminPage.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: AdminPageComponent
        }
    ]
})
export class AdminPageComponent extends BasePageComponent {

    pageName = 'AdminPage';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
