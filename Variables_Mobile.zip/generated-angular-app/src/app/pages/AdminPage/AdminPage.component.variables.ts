export const variables = {
    HrdbUserData: {
        _id: "wm-HrdbUserData-wm.LiveVariable-1561625102885",
        name: "HrdbUserData",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [],
        operation: "read",
        dataSet: [],
        type: "User",
        isList: true,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: true,
        autoUpdate: true,
        transformationRequired: false,
        liveSource: "hrdb",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "userId asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "userId",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "USER_ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 255,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    scale: 0
                },
                {
                    fieldName: "username",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "USERNAME",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 20,
                    precision: 19,
                    generator: "assigned",
                    isRelated: false,
                    scale: 2
                },
                {
                    fieldName: "password",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "PASSWORD",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 20,
                    precision: 19,
                    generator: "assigned",
                    isRelated: false,
                    scale: 2
                },
                {
                    fieldName: "role",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "ROLE",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 20,
                    precision: 19,
                    generator: "assigned",
                    isRelated: false,
                    scale: 2
                },
                {
                    fieldName: "tenantId",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "TENANT_ID",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 10,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                }
            ],
            entityName: "User",
            fullyQualifiedName: "com.variables_mobile.hrdb.User",
            tableType: "TABLE",
            primaryFields: ["userId"]
        },
        isDefault: true,
        bindCount: 1,
        tableName: "USER",
        tableType: "TABLE",
        properties: [],
        relatedTables: [],
        filterExpressions: {},
        package: "com.variables_mobile.hrdb.User"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
