import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './SecurityInfo.component.script';
import { getVariables } from './SecurityInfo.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-SecurityInfo',
    templateUrl: './SecurityInfo.component.html',
    styleUrls: ['./SecurityInfo.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: SecurityInfoComponent
        }
    ]
})
export class SecurityInfoComponent extends BasePageComponent {

    pageName = 'SecurityInfo';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
