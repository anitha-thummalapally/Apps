export const variables = {
    Alert_ErrorNotification: {
        _id: "wm-Alert_ErrorNotification-wm.NotificationVariable-1549880627631",
        name: "Alert_ErrorNotification",
        owner: "Page",
        category: "wm.NotificationVariable",
        dataBinding: [
            {
                target: "text",
                value: "Alert Dialog with Error",
                type: "string"
            },
            {
                target: "title",
                value: "Alert Alert",
                type: "string"
            },
            {
                target: "okButtonText",
                value: "Okay",
                type: "string"
            },
            {
                target: "alerttype",
                value: "error",
                type: "string"
            }
        ],
        operation: "alert",
        onOk: "Actions.Alert_WarningNotification.invoke()"
    },
    Alert_InformationNotification: {
        _id:
            "wm-Alert_InformationNotification-wm.NotificationVariable-1549880581339",
        name: "Alert_InformationNotification",
        owner: "Page",
        category: "wm.NotificationVariable",
        dataBinding: [
            {
                target: "text",
                value: "Alert With Information Successfull",
                type: "string"
            },
            {
                target: "okButtonText",
                value: "Ok",
                type: "string"
            },
            {
                target: "alerttype",
                value: "information",
                type: "string"
            }
        ],
        operation: "alert",
        onOk: "Actions.Alert_ErrorNotification.invoke()"
    },
    Alert_SuccessNotification: {
        _id: "wm-SuccessNotification-wm.NotificationVariable-1549880503357",
        name: "Alert_SuccessNotification",
        owner: "Page",
        category: "wm.NotificationVariable",
        dataBinding: [
            {
                target: "text",
                value: "Alert DIalog succesfull",
                type: "string"
            },
            {
                target: "title",
                value: "Alert Alert",
                type: "string"
            },
            {
                target: "okButtonText",
                value: "Ok",
                type: "string"
            },
            {
                target: "alerttype",
                value: "success",
                type: "string"
            }
        ],
        operation: "alert"
    },
    Alert_WarningNotification: {
        _id:
            "wm-Alert_WarningNotification-wm.NotificationVariable-1549880658318",
        name: "Alert_WarningNotification",
        owner: "Page",
        category: "wm.NotificationVariable",
        dataBinding: [
            {
                target: "text",
                value: "Alert With Warning succesfull",
                type: "string"
            },
            {
                target: "title",
                value: "Alert Alert",
                type: "string"
            },
            {
                target: "okButtonText",
                value: "Okay",
                type: "string"
            },
            {
                target: "alerttype",
                value: "warning",
                type: "string"
            }
        ],
        operation: "alert",
        onOk: "Actions.Alert_SuccessNotification.invoke()"
    },
    ConfirmNotification: {
        _id: "wm-ConfirmNotification-wm.NotificationVariable-1549880798129",
        name: "ConfirmNotification",
        owner: "Page",
        category: "wm.NotificationVariable",
        dataBinding: [
            {
                target: "text",
                value: "Confirm Dialog Popped",
                type: "string"
            },
            {
                target: "title",
                value: "Please accept the conditions before you move forward",
                type: "string"
            },
            {
                target: "okButtonText",
                value: "Yes",
                type: "string"
            },
            {
                target: "cancelButtonText",
                value: "No",
                type: "string"
            }
        ],
        operation: "confirm"
    },
    Hrdb_UserVariable: {
        _id: "wm-Hrdb_UserVariable-wm.LiveVariable-1549881367421",
        name: "Hrdb_UserVariable",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [],
        operation: "read",
        dataSet: [],
        type: "User",
        isList: false,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: true,
        autoUpdate: true,
        transformationRequired: false,
        liveSource: "hrdb",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "userId asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "userId",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "USER_ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 255,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    scale: 0
                },
                {
                    fieldName: "username",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "USERNAME",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 20,
                    precision: 19,
                    generator: "assigned",
                    isRelated: false,
                    scale: 2
                },
                {
                    fieldName: "password",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "PASSWORD",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 20,
                    precision: 19,
                    generator: "assigned",
                    isRelated: false,
                    scale: 2
                },
                {
                    fieldName: "role",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "ROLE",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 20,
                    precision: 19,
                    generator: "assigned",
                    isRelated: false,
                    scale: 2
                },
                {
                    fieldName: "tenantId",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "TENANT_ID",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 10,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                }
            ],
            entityName: "User",
            fullyQualifiedName: "com.variables_mobile.hrdb.User",
            tableType: "TABLE",
            primaryFields: ["userId"]
        },
        bindCount: 2,
        tableName: "USER",
        tableType: "TABLE",
        properties: [],
        relatedTables: [],
        filterFields: {},
        filterExpressions: {},
        package: "com.variables_mobile.hrdb.User"
    },
    NavigateToDeviceVariablesPage: {
        _id:
            "wm-NavigateToDeviceVariablesPage-wm.NavigationVariable-1549880943988",
        name: "NavigateToDeviceVariablesPage",
        owner: "Page",
        category: "wm.NavigationVariable",
        dataBinding: [
            {
                target: "pageName",
                value: "DeviceVariables",
                type: "string"
            }
        ],
        operation: "gotoPage",
        dataSet: [],
        pageTransitions: "flip"
    },
    NavigateToLogin: {
        _id: "wm-NavigateToLogin-wm.NavigationVariable-1549880896860",
        name: "NavigateToLogin",
        owner: "Page",
        category: "wm.NavigationVariable",
        dataBinding: [
            {
                target: "pageName",
                value: "Actions",
                type: "string"
            },
            {
                target: "segmentName",
                value: "segment_content3",
                type: "string"
            }
        ],
        operation: "gotoSegment",
        dataSet: [],
        pageTransitions: "pop"
    },
    TimerAction: {
        _id: "wm-TimerAction-wm.TimerVariable-1549881390501",
        name: "TimerAction",
        owner: "Page",
        category: "wm.TimerVariable",
        repeating: true,
        delay: 1000,
        onTimerFire: "Variables.Hrdb_UserVariable.listRecords()",
        startUpdate: true
    },
    ToasterNotification: {
        _id: "wm-ToasterNotification-wm.NotificationVariable-1549880833490",
        name: "ToasterNotification",
        owner: "Page",
        category: "wm.NotificationVariable",
        dataBinding: [
            {
                target: "content",
                value: "inline",
                type: "string"
            },
            {
                target: "text",
                value: "Toaster Notification Successful",
                type: "string"
            },
            {
                target: "duration",
                value: "4000",
                type: "number"
            },
            {
                target: "class",
                value: "Success",
                type: "string"
            },
            {
                target: "toasterPosition",
                value: "bottom left",
                type: "string"
            }
        ],
        operation: "toast"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
