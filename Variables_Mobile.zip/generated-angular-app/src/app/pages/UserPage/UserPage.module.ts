import { NgModule } from '@angular/core';
import { CommonModule as NgCommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeGenModule } from '../../app-codegen.module';



import { UserPageComponent } from './UserPage.component';

const components = [UserPageComponent];

const routes: Routes = [
    {
        path: '',
        component: UserPageComponent
    }
];

const requiredComponentModules = [
    
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        RouterModule.forChild(routes),
        NgCommonModule,
        AppCodeGenModule
    ],
    exports: components
})
export class UserPageModule {

}

