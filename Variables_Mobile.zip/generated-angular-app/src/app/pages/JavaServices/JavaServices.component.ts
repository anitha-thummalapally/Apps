import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './JavaServices.component.script';
import { getVariables } from './JavaServices.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-JavaServices',
    templateUrl: './JavaServices.component.html',
    styleUrls: ['./JavaServices.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: JavaServicesComponent
        }
    ]
})
export class JavaServicesComponent extends BasePageComponent {

    pageName = 'JavaServices';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
