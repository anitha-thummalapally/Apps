export const variables = {
    MyJavaServiceSampleJavaOperation: {
        _id:
            "wm-MyJavaServiceSampleJavaOperation-wm.ServiceVariable-1549880098988",
        name: "MyJavaServiceSampleJavaOperation",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type: "string",
        service: "MyJavaService",
        operation: "sampleJavaOperation",
        operationId: "MyJavaController_sampleJavaOperation",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: true,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "MyJava"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
