export const variables = {
    CountryList: {
        _id: "wm-CountryList-wm.Variable-1549882276199",
        name: "CountryList",
        owner: "Page",
        category: "wm.Variable",
        dataBinding: [],
        dataSet: [
            {
                dataValue: "United States"
            }
        ],
        type: "zcountry",
        isList: true,
        saveInPhonegap: false,
        twoWayBinding: false
    },
    Days: {
        _id: "wm-Days-wm.Variable-1549882294000",
        name: "Days",
        owner: "Page",
        category: "wm.Variable",
        dataBinding: [],
        dataSet: [
            {
                name: "Sunday",
                dataValue: 0
            },
            {
                name: "Monday",
                dataValue: 1
            },
            {
                name: "Tuesday",
                dataValue: 2
            },
            {
                name: "Wednesday",
                dataValue: 3
            },
            {
                name: "Thursday",
                dataValue: 4
            },
            {
                name: "Friday",
                dataValue: 5
            },
            {
                name: "Saturday",
                dataValue: 6
            }
        ],
        type: "zdays",
        isList: true,
        saveInPhonegap: false,
        twoWayBinding: false
    },
    DBModelVariable: {
        _id: "wm-staticVariable1-wm.Variable-1549882601793",
        name: "DBModelVariable",
        owner: "Page",
        category: "wm.Variable",
        dataBinding: [],
        dataSet: {
            birthdate: "2018-01-01",
            role: "admin",
            firstname: "Eric",
            empId: "1",
            zip: "500079",
            jobTitle: "Engineering",
            city: "Boston",
            managerId: "1",
            deptId: "1",
            lastname: "Lin",
            password: "eric.lin",
            employeeByManagerId: {},
            picurl: "",
            street: "LineStreet",
            state: "Calgary",
            tenantId: "1",
            username: "eric.lin",
            department: {
                q1: "12131",
                q2: "123121",
                q3: "1231243",
                q4: "1231241231",
                deptCode: "Eng",
                budget: "250000",
                deptId: "1",
                name: "Engineering",
                tenantId: "1",
                location: "CA"
            }
        },
        type: "com.variables_mobile.hrdb.Employee",
        isList: false,
        saveInPhonegap: false,
        twoWayBinding: false
    },
    IsList_StaticVariable: {
        _id: "wm-IsList_StaticVariable-wm.Variable-1549882244078",
        name: "IsList_StaticVariable",
        owner: "Page",
        category: "wm.Variable",
        dataBinding: [],
        dataSet: [
            {
                name: "Value1",
                dataValue: "DataValue1"
            }
        ],
        type: "entry",
        isList: true,
        saveInPhonegap: false,
        twoWayBinding: false
    },
    ModelVariable_ProcedureResponse: {
        _id: "wm-ModelVariable_ProcedureResponse-wm.Variable-1549882803946",
        name: "ModelVariable_ProcedureResponse",
        owner: "Page",
        category: "wm.Variable",
        dataBinding: [],
        dataSet: [
            {
                email: "eric.lin@wavemaker.com",
                employeeNumber: "12372",
                lastName: "Lin",
                firstName: "Eric",
                extension: "032",
                jobTitle: "Engineer Lead"
            }
        ],
        type:
            "com.variables_mobile.classicmodels.models.procedure.AllEmployeesResponseContent",
        isList: true,
        saveInPhonegap: false,
        twoWayBinding: false
    },
    Months: {
        _id: "wm-Months-wm.Variable-1549882306656",
        name: "Months",
        owner: "Page",
        category: "wm.Variable",
        dataBinding: [],
        dataSet: [
            {
                name: "January",
                dataValue: 1
            },
            {
                name: "February",
                dataValue: 2
            },
            {
                name: "March",
                dataValue: 3
            },
            {
                name: "April",
                dataValue: 4
            },
            {
                name: "May",
                dataValue: 5
            },
            {
                name: "June",
                dataValue: 6
            },
            {
                name: "July",
                dataValue: 7
            },
            {
                name: "August",
                dataValue: 8
            },
            {
                name: "September",
                dataValue: 9
            },
            {
                name: "October",
                dataValue: 10
            },
            {
                name: "November",
                dataValue: 11
            },
            {
                name: "December",
                dataValue: 12
            }
        ],
        type: "zmonths",
        isList: true,
        saveInPhonegap: false,
        twoWayBinding: false
    },
    USA_StatesList: {
        _id: "wm-USA_StatesList-wm.Variable-1549882331394",
        name: "USA_StatesList",
        owner: "Page",
        category: "wm.Variable",
        dataBinding: [],
        dataSet: [
            {
                name: "Alabama",
                dataValue: "AL"
            },
            {
                name: "Alaska",
                dataValue: "AK"
            },
            {
                name: "American Samoa",
                dataValue: "AS"
            },
            {
                name: "Arizona",
                dataValue: "AZ"
            },
            {
                name: "Arkansas",
                dataValue: "AR"
            },
            {
                name: "California",
                dataValue: "CA"
            },
            {
                name: "Colorado",
                dataValue: "CO"
            },
            {
                name: "Connecticut",
                dataValue: "CT"
            },
            {
                name: "Delaware",
                dataValue: "DE"
            },
            {
                name: "District of Columbia",
                dataValue: "DC"
            },
            {
                name: "Federated States of Micronesia",
                dataValue: "FM"
            },
            {
                name: "Florida",
                dataValue: "FL"
            },
            {
                name: "Georgia",
                dataValue: "GA"
            },
            {
                name: "Guam",
                dataValue: "GU"
            },
            {
                name: "Hawaii",
                dataValue: "HI"
            },
            {
                name: "Idaho",
                dataValue: "ID"
            },
            {
                name: "Illinois",
                dataValue: "IL"
            },
            {
                name: "Indiana",
                dataValue: "IN"
            },
            {
                name: "Iowa",
                dataValue: "IA"
            },
            {
                name: "Kansas",
                dataValue: "KS"
            },
            {
                name: "Kentucky",
                dataValue: "KY"
            },
            {
                name: "Louisiana",
                dataValue: "LA"
            },
            {
                name: "Maine",
                dataValue: "ME"
            },
            {
                name: "Marshall islands",
                dataValue: "MH"
            },
            {
                name: "Maryland",
                dataValue: "MD"
            },
            {
                name: "Massachusetts",
                dataValue: "MA"
            },
            {
                name: "Michigan",
                dataValue: "MI"
            },
            {
                name: "Minnesota",
                dataValue: "MN"
            },
            {
                name: "Mississippi",
                dataValue: "MS"
            },
            {
                name: "Missouri",
                dataValue: "MO"
            },
            {
                name: "Montana",
                dataValue: "MT"
            },
            {
                name: "Nebraska",
                dataValue: "NE"
            },
            {
                name: "Nevada",
                dataValue: "NV"
            },
            {
                name: "New Hampshire",
                dataValue: "NH"
            },
            {
                name: "New Jersey",
                dataValue: "NJ"
            },
            {
                name: "New Mexico",
                dataValue: "NM"
            },
            {
                name: "New York",
                dataValue: "NY"
            },
            {
                name: "North Carolina",
                dataValue: "NC"
            },
            {
                name: "North Dakota",
                dataValue: "ND"
            },
            {
                name: "Northern Mariana Islands",
                dataValue: "MP"
            },
            {
                name: "Ohio",
                dataValue: "OH"
            },
            {
                name: "Oklahoma",
                dataValue: "OK"
            },
            {
                name: "Oregon",
                dataValue: "OR"
            },
            {
                name: "Palau",
                dataValue: "PW"
            },
            {
                name: "Pennsylvania",
                dataValue: "PA"
            },
            {
                name: "Puerto Rico",
                dataValue: "PR"
            },
            {
                name: "Rhode Island",
                dataValue: "RI"
            },
            {
                name: "South Carolina",
                dataValue: "SC"
            },
            {
                name: "South Dakota",
                dataValue: "SD"
            },
            {
                name: "Tennessee",
                dataValue: "TN"
            },
            {
                name: "Texas",
                dataValue: "TX"
            },
            {
                name: "Utah",
                dataValue: "UT"
            },
            {
                name: "Vermont",
                dataValue: "VT"
            },
            {
                name: "Virgin Islands",
                dataValue: "VI"
            },
            {
                name: "Virginia",
                dataValue: "VA"
            },
            {
                name: "Washington",
                dataValue: "WA"
            },
            {
                name: "West Virginia",
                dataValue: "WV"
            },
            {
                name: "Wisconsin",
                dataValue: "WI"
            },
            {
                name: "Wyoming",
                dataValue: "WY"
            }
        ],
        type: "zusstate",
        isList: true,
        saveInPhonegap: false,
        twoWayBinding: false
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
