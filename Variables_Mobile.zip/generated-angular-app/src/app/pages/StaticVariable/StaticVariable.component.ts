import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './StaticVariable.component.script';
import { getVariables } from './StaticVariable.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-StaticVariable',
    templateUrl: './StaticVariable.component.html',
    styleUrls: ['./StaticVariable.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: StaticVariableComponent
        }
    ]
})
export class StaticVariableComponent extends BasePageComponent {

    pageName = 'StaticVariable';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
