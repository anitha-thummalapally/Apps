Add your application resources such as properties and xml files to this folder. 
Files added to this folder will be copied to WEB-INF/classes/ for deployment.
