Add custom jar files to this folder. Files added to this folder will be copied to WEB-INF for deployment and on the classpath.

Files you add directly to WEB-INF will likely be lost when you deploy your project, so jar files MUST be added here.
